
import 'antd/dist/antd.css';
import '../src/css/index.css';
import React from 'react';
import ReactDom from 'react-dom';
import App from './xiaolong/app';
ReactDom.render(
    <App/>
    ,document.getElementById("app")
)